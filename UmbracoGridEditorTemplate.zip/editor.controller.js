(function () {
    "use strict";

    function $fileinputname$Controller() {
        var vm = this;

    }

    angular.module("umbraco").controller("$name$.$fileinputname$Controller", $fileinputname$Controller);
})();