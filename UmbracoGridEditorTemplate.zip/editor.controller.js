(function () {
    "use strict";

    function $fileinputname$EditorController() {
        var vm = this;

    }

    angular.module("umbraco").controller("$name$.$fileinputname$EditorController", $fileinputname$EditorController);
})();